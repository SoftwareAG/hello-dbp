package HelloDBP;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.ibm.icu.util.TimeZone;
import java.time.Instant;
// --- <<IS-END-IMPORTS>> ---

public final class Utility

{
	// ---( internal utility methods )---

	final static Utility _instance = new Utility();

	static Utility _newInstance() { return new Utility(); }

	static Utility _cast(Object o) { return (Utility)o; }

	// ---( server methods )---




	public static final void dateToLong (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(dateToLong)>> ---
		// @sigtype java 3.5
		// [i] object:0:required date
		// [o] object:0:required dateLong
		// pipeline
		IDataCursor			pipelineCursor = pipeline.getCursor();
		Instant				time = ( (java.util.Date) IDataUtil.get( pipelineCursor, "date" ) ).toInstant();
		java.util.TimeZone	localZone = java.util.TimeZone.getDefault();
		
		IDataUtil.put( pipelineCursor, "dateLong", new Long( time.toEpochMilli() + localZone.getRawOffset() + localZone.getDSTSavings() ) );
		pipelineCursor.destroy();		
		// --- <<IS-END>> ---

                
	}



	public static final void sleep (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(sleep)>> ---
		// @sigtype java 3.5
		// [i] object:0:required sleepTimeMS
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		try {
			Thread.sleep(IDataUtil.getLong( pipelineCursor, "sleepTimeMS", 1000L ));
		}
		catch ( InterruptedException e ) {
			throw new ServiceException( e );
		}
		pipelineCursor.destroy();
		
			
		// --- <<IS-END>> ---

                
	}
}

